export const books = [
    {
      id: 1,
      title: "The Structure and Interpretation of Computer Programs",
      author: "Abelson, Sussman, and Sussman",
    },
    {
      id: 2,
      title: "Clean Code",
      author: "Robert J. Martin",
    },
    {
      id: 3,
      title: "You Don't Know JS",
      author: "Kyle Simpson",
    },
    {
      id: 4,
      title: "Eloquent JavaScript",
      author: "Marijn Haverbeke",
    },
    {
      id: 5,
      title: "The Art of Computer Programming",
      author: "Donald E. Knuth",
    },
    {
      id: 6,
      title: "The Pragmatic Programmer",
      author: "Andrew Hunt",
    },
    {
      id: 7,
      title: "Refactoring",
      author: "Martin Fowler",
    },
    {
      id: 8,
      title: "Island",
      author: "Aldous Huxley",
    },
];