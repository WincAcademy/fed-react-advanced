export function Book({ title, author }) {
    return (
        <p>{title} - {author}</p>
    )
}