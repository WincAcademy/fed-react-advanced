import { useState } from 'react';

export const App = () => {
    return (
        <>
            <h1>React Hooks Exercise Starter</h1>
        </>
    );
};