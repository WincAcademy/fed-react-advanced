import { Options } from "./components/Options"

export function App() {
    return (
        <Options />
    )
}

export default App