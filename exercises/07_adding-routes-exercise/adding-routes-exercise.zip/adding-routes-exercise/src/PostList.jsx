export const PostList = () => {
    return <h1>Post List</h1>;
};