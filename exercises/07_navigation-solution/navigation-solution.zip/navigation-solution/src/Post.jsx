export const Post = () => {
    return <h1>Post</h1>;
};