import { SimpleForm } from "./components/SimpleForm";

export function App() {
    return (
        <>
            <h1>RHF Example</h1>

            <SimpleForm />
        </>
    );
}