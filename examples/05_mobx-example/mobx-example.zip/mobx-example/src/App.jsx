import Counter from "./components/Counter";

export function App() {
    return (
        <Counter />
    );
}